from scr.game import Game
from scr.infrastructure import Infrastructure

if __name__=='__main__':
    game=Game(Infrastructure())
    game.loop() 